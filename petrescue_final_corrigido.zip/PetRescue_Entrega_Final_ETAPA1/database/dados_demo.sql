-- Dados de demonstração do Pet Rescue
-- Execute este arquivo após database/schema.sql.
-- Credenciais acadêmicas de demonstração:
-- E-mail: admin@petrescue.com
-- Senha: Admin123

USE pet_rescue;

-- Administrador (senha armazenada somente como hash bcrypt)
INSERT INTO administrador (nome, email, senha_hash)
SELECT 'Administrador Pet Rescue', 'admin@petrescue.com', '$2b$10$JevQ0qJPLDhQjeP77L0wMe6MIsPzQMa8U/EOkOT6SsISt9MZZi2.S'
WHERE NOT EXISTS (
    SELECT 1 FROM administrador WHERE email = 'admin@petrescue.com'
);

-- Animais fictícios para demonstração
INSERT INTO animal (nome, especie, raca, idade, porte, status, data_resgate, descricao, foto_url)
SELECT 'Luna', 'Cachorro', 'Sem raça definida', '2 anos', 'medio', 'disponivel', '2026-07-15',
       'Luna é uma cadela carinhosa, sociável e cheia de energia. Procura uma família responsável que possa oferecer carinho, cuidados e um lar seguro.',
       '/img/pets.jpg'
WHERE NOT EXISTS (SELECT 1 FROM animal WHERE nome = 'Luna');

INSERT INTO animal (nome, especie, raca, idade, porte, status, data_resgate, descricao, foto_url)
SELECT 'Thor', 'Cachorro', 'Sem raça definida', '4 anos', 'grande', 'disponivel', '2026-06-20',
       'Thor é um cão tranquilo e companheiro. Gosta de contato com pessoas e procura um lar onde possa receber atenção e cuidados.',
       '/img/pets2.png'
WHERE NOT EXISTS (SELECT 1 FROM animal WHERE nome = 'Thor');

INSERT INTO animal (nome, especie, raca, idade, porte, status, data_resgate, descricao, foto_url)
SELECT 'Nina', 'Gato', 'Sem raça definida', '1 ano', 'pequeno', 'disponivel', '2026-08-03',
       'Nina é uma gata jovem, curiosa e afetuosa. Está disponível para adoção responsável e busca uma família que respeite seu tempo de adaptação.',
       '/img/pets3.jpg'
WHERE NOT EXISTS (SELECT 1 FROM animal WHERE nome = 'Nina');

-- Solicitação fictícia para demonstrar o painel administrativo
INSERT INTO solicitacao_adocao
    (id_animal, nome_interessado, email_interessado, telefone, mensagem, status_solicitacao)
SELECT a.id_animal, 'Pessoa Demonstração', 'demo@petrescue.com', '(53) 99999-9999',
       'Solicitação fictícia utilizada somente para demonstração acadêmica.', 'pendente'
FROM animal a
WHERE a.nome = 'Luna'
  AND NOT EXISTS (
      SELECT 1 FROM solicitacao_adocao WHERE email_interessado = 'demo@petrescue.com'
  )
LIMIT 1;
