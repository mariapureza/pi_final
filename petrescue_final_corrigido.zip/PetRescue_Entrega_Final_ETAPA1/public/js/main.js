const slides = document.getElementById('slides');
        const indicators = document.querySelectorAll('.indicator');
        const totalSlides = slides.children.length;
        let currentSlide = 0;

        function setSlide(index) {
            currentSlide = (index + totalSlides) % totalSlides;
            slides.style.transform = `translateX(-${currentSlide * 100}%)`;
            indicators.forEach((indicator, i) => {
                indicator.classList.toggle('active', i === currentSlide);
                indicator.setAttribute('aria-current', i === currentSlide ? 'true' : 'false');
            });
        }

        indicators.forEach((indicator) => {
            indicator.addEventListener('click', () => setSlide(Number(indicator.dataset.slide)));
        });

        setInterval(() => setSlide(currentSlide + 1), 5000);

        const inputPesquisa = document.getElementById('pesquisa');
        const btnBuscar = document.getElementById('btnBuscar');
        const cards = [...document.querySelectorAll('.card')];
        const semResultados = document.getElementById('semResultados');

        function normalizar(texto) {
            return texto.normalize('NFD').replace(/[\u0300-\u036f]/g, '').toLowerCase().trim();
        }

        function pesquisar() {
            const termo = normalizar(inputPesquisa.value);
            let visiveis = 0;
            cards.forEach((card) => {
                const corresponde = normalizar(card.dataset.search).includes(termo);
                card.classList.toggle('hidden', !corresponde);
                if (corresponde) visiveis++;
            });
            semResultados.style.display = visiveis ? 'none' : 'block';
        }

        btnBuscar.addEventListener('click', pesquisar);
        inputPesquisa.addEventListener('input', pesquisar);
