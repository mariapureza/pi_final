# Pasta reservada

Regras de negócio e validações serão adicionadas nas próximas etapas.
