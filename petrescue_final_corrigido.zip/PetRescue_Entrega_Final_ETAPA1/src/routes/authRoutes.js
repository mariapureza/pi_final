const express = require('express');
const bcrypt = require('bcrypt');

const router = express.Router();
const db = require('../config/database');


// ======================================================
// EXIBIR TELA DE LOGIN
// ======================================================
router.get('/login', (req, res) => {

    if (req.session.administrador) {
        return res.redirect('/admin');
    }

    res.render('login', {
        erro: null
    });

});


// ======================================================
// PROCESSAR LOGIN
// ======================================================
router.post('/login', async (req, res) => {

    try {

        const { email, senha } = req.body;

        if (!email || !senha) {

            return res.status(400).render('login', {
                erro: 'Informe o e-mail e a senha.'
            });

        }


        const [resultado] = await db.query(`
            SELECT
                id_administrador,
                nome,
                email,
                senha_hash
            FROM administrador
            WHERE email = ?
            LIMIT 1
        `, [email.trim()]);


        if (resultado.length === 0) {

            return res.status(401).render('login', {
                erro: 'E-mail ou senha inválidos.'
            });

        }


        const administrador = resultado[0];


        const senhaCorreta = await bcrypt.compare(
            senha,
            administrador.senha_hash
        );


        if (!senhaCorreta) {

            return res.status(401).render('login', {
                erro: 'E-mail ou senha inválidos.'
            });

        }


        // Criar sessão
        req.session.administrador = {
            id: administrador.id_administrador,
            nome: administrador.nome,
            email: administrador.email
        };


        res.redirect('/admin');


    } catch (error) {

        console.error(
            'Erro no login:',
            error
        );

        res.status(500).render('login', {
            erro: 'Ocorreu um erro ao realizar o login.'
        });

    }

});


// ======================================================
// LOGOUT
// ======================================================
router.get('/logout', (req, res) => {

    req.session.destroy(() => {
        res.redirect('/login');
    });

});


module.exports = router;