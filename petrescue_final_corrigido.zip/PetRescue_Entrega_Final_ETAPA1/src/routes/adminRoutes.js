const express = require('express');

const router = express.Router();
const db = require('../config/database');

const verificarAutenticacao =
    require('../middleware/authMiddleware');


// Todas as rotas exigem login
router.use(verificarAutenticacao);


// ======================================================
// PAINEL ADMINISTRATIVO
// ======================================================
router.get('/', (req, res) => {

    res.render('admin/dashboard', {
        administrador: req.session.administrador
    });

});


// ======================================================
// LISTAR ANIMAIS
// ======================================================
router.get('/animais', async (req, res) => {

    try {

        const [animais] = await db.query(`
            SELECT *
            FROM animal
            ORDER BY id_animal DESC
        `);

        res.render('admin/animais', {
            administrador: req.session.administrador,
            animais
        });

    } catch (error) {

        console.error(
            'Erro ao carregar animais:',
            error
        );

        res.status(500).send(
            'Erro ao carregar os animais.'
        );

    }

});


// ======================================================
// FORMULÁRIO NOVO ANIMAL
// ======================================================
router.get('/animais/novo', (req, res) => {

    res.render('admin/animal-form', {

        animal: null,

        titulo:
            'Cadastrar novo animal',

        acao:
            '/admin/animais/novo'

    });

});


// ======================================================
// SALVAR NOVO ANIMAL
// ======================================================
router.post('/animais/novo', async (req, res) => {

    try {

        const {
            nome,
            especie,
            raca,
            idade,
            porte,
            status,
            data_resgate,
            descricao,
            foto_url
        } = req.body;


        if (!nome || !especie || !porte || !status) {

            return res.status(400).send(
                'Preencha os campos obrigatórios.'
            );

        }


        await db.query(`
            INSERT INTO animal
            (
                nome,
                especie,
                raca,
                idade,
                porte,
                status,
                data_resgate,
                descricao,
                foto_url
            )
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
        `, [

            nome.trim(),

            especie.trim(),

            raca
                ? raca.trim()
                : null,

            idade
                ? idade.trim()
                : null,

            porte,

            status,

            data_resgate || null,

            descricao
                ? descricao.trim()
                : null,

            foto_url
                ? foto_url.trim()
                : '/img/pets.jpg'

        ]);


        res.redirect(
            '/admin/animais'
        );


    } catch (error) {

        console.error(
            'Erro ao cadastrar animal:',
            error
        );

        res.status(500).send(
            'Erro ao cadastrar o animal.'
        );

    }

});


// ======================================================
// FORMULÁRIO DE EDIÇÃO
// ======================================================
router.get('/animais/:id/editar', async (req, res) => {

    try {

        const idAnimal =
            req.params.id;


        const [resultado] = await db.query(`
            SELECT *
            FROM animal
            WHERE id_animal = ?
        `, [idAnimal]);


        if (resultado.length === 0) {

            return res.status(404).send(
                'Animal não encontrado.'
            );

        }


        res.render(
            'admin/animal-form',
            {

                animal:
                    resultado[0],

                titulo:
                    'Editar animal',

                acao:
                    `/admin/animais/${idAnimal}/editar`

            }
        );


    } catch (error) {

        console.error(
            'Erro ao carregar animal:',
            error
        );

        res.status(500).send(
            'Erro ao carregar o animal.'
        );

    }

});


// ======================================================
// SALVAR EDIÇÃO
// ======================================================
router.post('/animais/:id/editar', async (req, res) => {

    try {

        const idAnimal =
            req.params.id;


        const {
            nome,
            especie,
            raca,
            idade,
            porte,
            status,
            data_resgate,
            descricao,
            foto_url
        } = req.body;


        if (!nome || !especie || !porte || !status) {

            return res.status(400).send(
                'Preencha os campos obrigatórios.'
            );

        }


        await db.query(`
            UPDATE animal
            SET
                nome = ?,
                especie = ?,
                raca = ?,
                idade = ?,
                porte = ?,
                status = ?,
                data_resgate = ?,
                descricao = ?,
                foto_url = ?
            WHERE id_animal = ?
        `, [

            nome.trim(),

            especie.trim(),

            raca
                ? raca.trim()
                : null,

            idade
                ? idade.trim()
                : null,

            porte,

            status,

            data_resgate || null,

            descricao
                ? descricao.trim()
                : null,

            foto_url
                ? foto_url.trim()
                : '/img/pets.jpg',

            idAnimal

        ]);


        res.redirect(
            '/admin/animais'
        );


    } catch (error) {

        console.error(
            'Erro ao editar animal:',
            error
        );

        res.status(500).send(
            'Erro ao editar o animal.'
        );

    }

});


// ======================================================
// EXCLUIR ANIMAL
// ======================================================
router.post('/animais/:id/excluir', async (req, res) => {

    try {

        const idAnimal =
            req.params.id;


        // Verifica se possui solicitações
        const [solicitacoes] = await db.query(`
            SELECT id_solicitacao
            FROM solicitacao_adocao
            WHERE id_animal = ?
            LIMIT 1
        `, [idAnimal]);


        if (solicitacoes.length > 0) {

            return res.status(400).send(
                'Este animal possui solicitações de adoção e não pode ser excluído. Altere o status para adotado, se necessário.'
            );

        }


        await db.query(`
            DELETE FROM animal
            WHERE id_animal = ?
        `, [idAnimal]);


        res.redirect(
            '/admin/animais'
        );


    } catch (error) {

        console.error(
            'Erro ao excluir animal:',
            error
        );

        res.status(500).send(
            'Erro ao excluir o animal.'
        );

    }

});

// ======================================================
// LISTAR SOLICITAÇÕES
// ======================================================
router.get('/solicitacoes', async (req, res) => {

    try {

        const [solicitacoes] = await db.query(`
            SELECT
                s.id_solicitacao,
                s.nome_interessado,
                s.email_interessado,
                s.telefone,
                s.mensagem,
                s.data_solicitacao,
                s.status_solicitacao,
                a.nome AS nome_animal
            FROM solicitacao_adocao s
            INNER JOIN animal a
                ON s.id_animal = a.id_animal
            ORDER BY s.data_solicitacao DESC
        `);

        res.render('admin/solicitacoes', {
            administrador: req.session.administrador,
            solicitacoes
        });

    } catch (error) {

        console.error(
            'Erro ao carregar solicitações:',
            error
        );

        res.status(500).send(
            'Erro ao carregar as solicitações.'
        );

    }

});


// ======================================================
// ATUALIZAR STATUS DA SOLICITAÇÃO
// ======================================================
router.post('/solicitacoes/:id/status', async (req, res) => {

    try {

        const idSolicitacao =
            req.params.id;

        const {
            status_solicitacao
        } = req.body;


        const statusPermitidos = [
            'pendente',
            'aprovada',
            'rejeitada'
        ];


        if (
            !statusPermitidos.includes(
                status_solicitacao
            )
        ) {

            return res.status(400).send(
                'Status inválido.'
            );

        }


        await db.query(`
            UPDATE solicitacao_adocao
            SET status_solicitacao = ?
            WHERE id_solicitacao = ?
        `, [
            status_solicitacao,
            idSolicitacao
        ]);


        res.redirect(
            '/admin/solicitacoes'
        );


    } catch (error) {

        console.error(
            'Erro ao atualizar solicitação:',
            error
        );

        res.status(500).send(
            'Erro ao atualizar a solicitação.'
        );

    }

});
module.exports = router;