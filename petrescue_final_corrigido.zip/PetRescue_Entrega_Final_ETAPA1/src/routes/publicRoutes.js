const express = require('express');
const router = express.Router();
const db = require('../config/database');


// ======================================================
// PÁGINA INICIAL - CATÁLOGO DE ANIMAIS
// ======================================================
router.get('/', async (req, res) => {

    try {

        const [animais] = await db.query(`
            SELECT
                id_animal,
                nome,
                especie,
                raca,
                idade,
                porte,
                status,
                descricao,
                foto_url
            FROM animal
            WHERE status IN ('disponivel', 'em_processo')
            ORDER BY id_animal DESC
        `);

        res.render('index', {
            animais
        });

    } catch (error) {

        console.error(
            'Erro ao buscar animais:',
            error
        );

        res.status(500).send(
            'Erro ao carregar os animais.'
        );

    }

});


// ======================================================
// PÁGINA DE DETALHES DO ANIMAL
// ======================================================
router.get('/animais/:id', async (req, res) => {

    try {

        const idAnimal = req.params.id;

        const [resultado] = await db.query(`
            SELECT
                id_animal,
                nome,
                especie,
                raca,
                idade,
                porte,
                status,
                data_resgate,
                descricao,
                foto_url
            FROM animal
            WHERE id_animal = ?
        `, [idAnimal]);


        // Se não existir animal com esse ID
        if (resultado.length === 0) {

            return res.status(404).send(
                'Animal não encontrado.'
            );

        }


        const animal = resultado[0];

        res.render('animal', {
            animal
        });


    } catch (error) {

        console.error(
            'Erro ao buscar animal:',
            error
        );

        res.status(500).send(
            'Erro ao carregar os dados do animal.'
        );

    }

});

// ======================================================
// FORMULÁRIO DE INTERESSE EM ADOÇÃO
// ======================================================
router.get('/animais/:id/interesse', async (req, res) => {

    try {

        const idAnimal = req.params.id;

        const [resultado] = await db.query(`
            SELECT
                id_animal,
                nome,
                especie,
                raca,
                idade,
                porte,
                status,
                foto_url
            FROM animal
            WHERE id_animal = ?
        `, [idAnimal]);

        if (resultado.length === 0) {

            return res.status(404).send(
                'Animal não encontrado.'
            );

        }

        const animal = resultado[0];

        if (animal.status !== 'disponivel') {

            return res.status(400).send(
                'Este animal não está disponível para uma nova solicitação de adoção.'
            );

        }

        res.render('interesse', {
            animal
        });

    } catch (error) {

        console.error(
            'Erro ao abrir formulário de adoção:',
            error
        );

        res.status(500).send(
            'Erro ao carregar o formulário.'
        );

    }

});
// ======================================================
// SALVAR INTERESSE EM ADOÇÃO
// ======================================================
router.post('/animais/:id/interesse', async (req, res) => {

    try {

        const idAnimal = req.params.id;

        const {
            nome_interessado,
            email_interessado,
            telefone,
            mensagem
        } = req.body;


        // Validação básica
        if (!nome_interessado || !email_interessado) {

            return res.status(400).send(
                'Nome e e-mail são obrigatórios.'
            );

        }


        // Verificar se o animal existe e está disponível
        const [animais] = await db.query(`
            SELECT
                id_animal,
                nome,
                status
            FROM animal
            WHERE id_animal = ?
        `, [idAnimal]);


        if (animais.length === 0) {

            return res.status(404).send(
                'Animal não encontrado.'
            );

        }


        const animal = animais[0];


        if (animal.status !== 'disponivel') {

            return res.status(400).send(
                'Este animal não está disponível para uma nova solicitação de adoção.'
            );

        }


        // Salvar solicitação
        await db.query(`
            INSERT INTO solicitacao_adocao
            (
                id_animal,
                nome_interessado,
                email_interessado,
                telefone,
                mensagem
            )
            VALUES (?, ?, ?, ?, ?)
        `, [
            idAnimal,
            nome_interessado.trim(),
            email_interessado.trim(),
            telefone ? telefone.trim() : null,
            mensagem ? mensagem.trim() : null
        ]);


        // Mostrar confirmação
        res.render('sucesso', {
            animal
        });


    } catch (error) {

        console.error(
            'Erro ao salvar solicitação de adoção:',
            error
        );

        res.status(500).send(
            'Erro ao registrar a solicitação de adoção.'
        );

    }

});
module.exports = router;