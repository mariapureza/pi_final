# Pasta reservada

Middleware de autenticação e controle de acesso será adicionado nas próximas etapas.
