function verificarAutenticacao(req, res, next) {

    if (!req.session || !req.session.administrador) {

        return res.redirect('/login');

    }

    next();

}

module.exports = verificarAutenticacao;