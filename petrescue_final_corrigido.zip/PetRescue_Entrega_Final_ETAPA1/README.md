# Pet Rescue

Projeto integrador desenvolvido para as disciplinas de **Engenharia de Software III** e **Programação Back-End** do curso de Análise e Desenvolvimento de Sistemas da Universidade Católica de Pelotas.

## Tema

Desenvolvimento de uma Plataforma Web para Adoção Responsável e Gestão de Animais Resgatados.

## Objetivo

O Pet Rescue centraliza a divulgação de animais resgatados e o registro de interesse de pessoas que desejam realizar uma adoção responsável. A aplicação possui um módulo público para consulta dos animais e um módulo administrativo autenticado para gerenciamento dos animais e das solicitações de adoção.

## Funcionalidades implementadas

### Área pública

- Catálogo de animais armazenados no MySQL.
- Pesquisa por nome, espécie, raça, idade e porte.
- Página individual com foto, descrição, dados e status do animal.
- Formulário de manifestação de interesse em adoção.
- Validação dos campos obrigatórios.
- Persistência das solicitações no banco de dados.
- Confirmação após o envio da solicitação.

### Área administrativa

- Login de administrador por e-mail e senha.
- Senha armazenada com hash bcrypt.
- Controle de sessão e proteção das rotas administrativas.
- Cadastro, listagem e edição de animais.
- Atualização do status do animal: `disponivel`, `em_processo` e `adotado`.
- Exclusão de animais sem solicitações vinculadas.
- Visualização das solicitações de adoção.
- Atualização do status das solicitações: `pendente`, `aprovada` e `rejeitada`.
- Logout administrativo.

## Tecnologias utilizadas

- Node.js
- Express
- JavaScript
- EJS
- HTML5 e CSS3
- MySQL
- mysql2
- bcrypt
- express-session
- dotenv

## Estrutura do projeto

```text
PetRescue_Entrega_Final_ETAPA1/
├── app.js
├── package.json
├── package-lock.json
├── .env.example
├── .gitignore
├── database/
│   ├── schema.sql
│   └── dados_demo.sql
├── public/
│   ├── css/
│   ├── js/
│   └── img/
├── src/
│   ├── config/
│   ├── controllers/
│   ├── middleware/
│   ├── models/
│   ├── routes/
│   └── services/
└── views/
    ├── index.ejs
    ├── animal.ejs
    ├── interesse.ejs
    ├── sucesso.ejs
    ├── login.ejs
    └── admin/
        ├── dashboard.ejs
        ├── animais.ejs
        ├── animal-form.ejs
        └── solicitacoes.ejs
```

## Como executar

### 1. Pré-requisitos

É necessário ter **Node.js**, **npm** e **MySQL** instalados.

### 2. Instalar as dependências

Na raiz do projeto:

```bash
npm install
```

### 3. Criar o banco de dados

Execute no MySQL, nesta ordem:

1. `database/schema.sql`
2. `database/dados_demo.sql`

O primeiro arquivo cria o banco e as tabelas. O segundo adiciona os dados fictícios usados na demonstração.

### 4. Configurar as variáveis de ambiente

Crie um arquivo `.env` na raiz, utilizando `.env.example` como modelo:

```env
DB_HOST=localhost
DB_USER=root
DB_PASSWORD=sua_senha_do_mysql
DB_NAME=pet_rescue
DB_PORT=3306
PORT=3000
SESSION_SECRET=uma_chave_de_sessao
```

O arquivo `.env` não deve ser publicado nem enviado junto ao projeto.

### 5. Iniciar a aplicação

```bash
npm start
```

A aplicação ficará disponível em:

```text
http://localhost:3000
```

## Credenciais de demonstração

Após executar `database/dados_demo.sql`:

```text
E-mail: admin@petrescue.com
Senha: Admin123
```

Essas credenciais são exclusivamente acadêmicas e utilizam uma senha armazenada no banco como hash bcrypt.

## Rotas principais

- `/` — catálogo público.
- `/animais/:id` — detalhes do animal.
- `/animais/:id/interesse` — formulário de interesse.
- `/login` — login administrativo.
- `/admin` — painel administrativo autenticado.
- `/admin/animais` — gerenciamento de animais.
- `/admin/solicitacoes` — gerenciamento das solicitações.

## Banco de dados

O sistema possui três entidades principais:

- **Administrador:** usuário autorizado a acessar o painel.
- **Animal:** dados dos animais divulgados na plataforma.
- **Solicitação de adoção:** manifestação de interesse vinculada a um animal.

A relação entre Animal e Solicitação de Adoção é de 1:N. A chave estrangeira utiliza `ON DELETE RESTRICT`, preservando solicitações já registradas.

## Segurança e validação

- Senha administrativa armazenada com bcrypt.
- Sessões para controle de acesso.
- Middleware protegendo as rotas administrativas.
- Consultas parametrizadas com mysql2.
- Validação básica no servidor.
- Restrição dos status aceitos pelas regras do sistema.
- `.env` e `node_modules/` ignorados pelo Git.

## Testes realizados

Foram testados manualmente os principais fluxos:

- carregamento do catálogo;
- pesquisa dos animais;
- página de detalhes;
- envio e persistência de solicitação;
- login válido e inválido;
- bloqueio de rota administrativa sem autenticação;
- cadastro, edição, status e exclusão de animais;
- visualização e atualização das solicitações;
- logout.

## Privacidade

Os dados e conteúdos utilizados na demonstração são fictícios ou destinados exclusivamente à atividade acadêmica.

## Autores

- João Vitor Milech dos Santos
- Maria Eduarda Duarte Pureza

## Instituição

**Universidade Católica de Pelotas**  
Curso de Análise e Desenvolvimento de Sistemas  
Disciplinas: Engenharia de Software III e Programação Back-End  
Professores: Morgana Macedo Azevedo da Rosa e Rogério Albandes  
Ano: 2026

## Vídeo de apresentação

O link da demonstração em vídeo pode ser adicionado aqui após a gravação.

## Observação

Projeto desenvolvido exclusivamente para fins acadêmicos.
