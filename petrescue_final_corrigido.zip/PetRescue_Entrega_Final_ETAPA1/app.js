const express = require('express');
const path = require('path');
const session = require('express-session');
require('dotenv').config();

const db = require('./src/config/database');

const publicRoutes = require('./src/routes/publicRoutes');
const authRoutes = require('./src/routes/authRoutes');
const adminRoutes = require('./src/routes/adminRoutes');


const app = express();


// ======================================================
// CONFIGURAÇÕES
// ======================================================

app.set('view engine', 'ejs');

app.set(
    'views',
    path.join(__dirname, 'views')
);


// Arquivos públicos
app.use(
    express.static(
        path.join(__dirname, 'public')
    )
);


// Ler formulários
app.use(
    express.urlencoded({
        extended: true
    })
);


// ======================================================
// SESSÃO
// ======================================================

app.use(
    session({

        secret:
            process.env.SESSION_SECRET ||
            'pet-rescue-chave-academica',

        resave: false,

        saveUninitialized: false,

        cookie: {

            httpOnly: true,

            maxAge:
                1000 *
                60 *
                60 *
                2
        }

    })
);


// ======================================================
// ROTAS
// ======================================================

app.use('/', publicRoutes);

app.use('/', authRoutes);

app.use('/admin', adminRoutes);


// ======================================================
// TESTE DO BANCO
// ======================================================

db.getConnection()

    .then(connection => {

        console.log(
            'Conexão com MySQL realizada com sucesso.'
        );

        connection.release();

    })

    .catch(error => {

        console.error(
            'Erro ao conectar com MySQL:',
            error.message
        );

    });


// ======================================================
// SERVIDOR
// ======================================================

const PORT =
    process.env.PORT ||
    3000;


app.listen(PORT, () => {

    console.log(
        `Pet Rescue em execução em http://localhost:${PORT}`
    );

});
